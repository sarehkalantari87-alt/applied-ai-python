# مثال ساده از تعریف case
# a = 10
# match a:
#     case 20:
#         print('bad')
#     case 30:
#         print('very bad')
#     case 10:
#         print('good')
# ////////////////////////////////////////////
#برنامه ماشین حساب با استفاده از  match و case
# a=int(input("enter one number:"))
# c=input("select your choice *,/,+,-,**:")
# b=int(input("enter tow number:"))
# match c:
#     case '*':
#         print(a*b)
#     case '/':
#         print(a/b)
#     case '+':
#         print(a+b)
#     case '-':
#         print(a-b)
#     case _:
#         print(a**b)
# ////////////////////////////////////////////
#منوی انتخاب گزینه
# choice = input("select your choice (start , load , exit ):")
# match choice:
#     case "1":
#         print("start game")
#     case "2":
#         print("loading")
#     case "3":
#         print("exit of game")
#     case _:
#         print("error")
# ////////////////////////////////////////////
# نمایش نام روز هفته از روی عدد
# day= int(input("enter the day for 1 to 7"))
# match day:
#     case 1:
#         print("Saturday")
#     case 2:
#         print("sunday")
#     case 3:
#         print("monday")
#     case 4:
#         print("tuesday")
#     case 5:
#         print("wednesday")
#     case 6:
#         print("thursday")
#     case 7:
#         print("friday")
#     case _:
#         print("عدد خارج از محدوده است")
# ////////////////////////////////////////////
# طبقه‌بندی نمره
# a = int(input("enter a number: "))
# match  a:
#     case a if a > 80 and a <= 100:
#         g = "A"
#     case a if a <= 80 and a >= 60:
#         g = "B"
#     case a if a <= 60 and a >=40:
#         g = "C"
#     case _:
#         g = "D"
#
# print(g)
# ////////////////////////////////////////////
# حلقه FOR
# چاپ اعداد از ۱ تا ۱۰
# for i in range(1, 11):
#     print(i)
# ////////////////////////////////////////////
# چاپ اعداد زوج از ۲ تا 50
# for i in range(2, 51, 2):
#     print(i)
# ////////////////////////////////////////////
# جمع تمام اعداد از ۱ تا ۱۰۰
# s=0
# for i in range(1,101):
#     s+=i
# print(s)
# ////////////////////////////////////////////
# جدول ضرب عدد ۵
# for i in range(1,11):
#     print(i*5)
# ////////////////////////////////////////////
# چاپ حروف یک رشته
# a='python'
# for i in a:
#     print(i)
# ////////////////////////////////////////////
# شمارش معکوس عدد 10
# for i in range(10,0,-1):
#     print(i)
# ////////////////////////////////////////////
# محاسبه فاکتوریل
# n = int(input('enter the number:'))
# fact = 1
# for i in range(1, n+1):
#     fact *= i
# print(f"فاکتوریل {n} = {fact}")
# ////////////////////////////////////////////
# چاپ ستاره
# for i in range(1, 6):
#     print("*" * i)
# ////////////////////////////////////////////
# پیمایش لیست
# a=['apple','banana','orange','mango']
# for i in a:
#     print(i)
# ////////////////////////////////////////////
# چاپ اعداد از ۱ تا ۵
# count = 1
# while count <= 5:
#     print(count)
#     count += 1
# print('end')
# ////////////////////////////////////////////
# جمع اعداد تا وقتی که کاربر عدد صفر وارد کند
# t = 0
# num = int(input("enter the number  for number 0:"))
# while num != 0:
#     t += num
#     num = int(input("enter a number: "))
# print("مجموع:", t)
# ////////////////////////////////////////////
# بررسی رمز عبور
# password = "1234"
# while True:
#     user= input("enter a password: ")
#     if user == password:
#         print("your welcome")
#         break
#     else:
#         print("error")



