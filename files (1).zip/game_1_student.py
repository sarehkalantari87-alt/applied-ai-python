import turtle
import random
# --- تنظیمات صفحه ---
screen = turtle.Screen()
screen.title("GAME")
screen.bgcolor("black")
screen.setup(width=500, height=500)
STEP = 20

# ---  (بازیکن) ---
player = turtle.Turtle()
player.shape("circle")
player.color("white")
player.penup()
player.speed(0)
