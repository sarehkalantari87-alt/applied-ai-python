import turtle
import time

wn = turtle.Screen()
wn.title("My Game")
wn.bgcolor("black")
wn.setup(width=800, height=600)
wn.tracer(0)


# ساختن شکل اول (پارو سمت چپ)
poll_a = turtle.Turtle()
poll_a.speed(0)
poll_a.shape("square")
poll_a.color("white")
poll_a.shapesize(stretch_wid=5, stretch_len=1)
poll_a.penup()
poll_a.goto(-350, 0)

# ساختن شکل دوم (پارو سمت راست)
poll_b = turtle.Turtle()
poll_b.speed(0)
poll_b.shape("square")
poll_b.color("white")
poll_b.shapesize(stretch_wid=5, stretch_len=1)
poll_b.penup()
poll_b.goto(350, 0)

# ساخت توپ
ball = turtle.Turtle()
ball.speed(0)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 2
ball.dy = -2

# قلم نمایش پیام
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()


def show_game_over(loser_text):
    pen.clear()
    pen.goto(0, 0)
    pen.write(loser_text, align="center", font=("Aller", 36, "bold"))


# دستورات حرکت پاروها (با محدود کردن به داخل صفحه)
def poll_a_up():
    y = poll_a.ycor()
    if y < 250:
        poll_a.sety(y + 20)


def poll_a_down():
    y = poll_a.ycor()
    if y > -250:
        poll_a.sety(y - 20)


def poll_b_up():
    y = poll_b.ycor()
    if y < 250:
        poll_b.sety(y + 20)


def poll_b_down():
    y = poll_b.ycor()
    if y > -250:
        poll_b.sety(y - 20)


# صفحه کلید
wn.listen()
wn.onkeypress(poll_a_up, "w")
wn.onkeypress(poll_a_down, "s")
wn.onkeypress(poll_b_up, "Up")
wn.onkeypress(poll_b_down, "Down")


# حلقه‌ی اصلی بازی
try:
    game_over = False
    while True:
        wn.update()
        time.sleep(0.015)   # <-- همین خط سرعت زیاد رو کنترل می‌کنه

        if game_over:
            continue

        # حرکت توپ
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        # برخورد با مرز بالا و پایین
        if ball.ycor() > 290:
            ball.sety(290)
            ball.dy *= -1
        if ball.ycor() < -290:
            ball.sety(-290)
            ball.dy *= -1

        # برخورد با پارو سمت راست
        if ball.xcor() > 340 and (poll_b.ycor() - 50 < ball.ycor() < poll_b.ycor() + 50):
            ball.setx(340)
            ball.dx *= -1

        # برخورد با پارو سمت چپ
        if ball.xcor() < -340 and (poll_a.ycor() - 50 < ball.ycor() < poll_a.ycor() + 50):
            ball.setx(-340)
            ball.dx *= -1

        # اگه توپ از سمت راست رد بشه و به پارو نخورده باشه => گیم اور
        if ball.xcor() > 350:
            ball.goto(1000, 1000)
            show_game_over("GAME OVER\nPlayer A Wins!")
            game_over = True

        # اگه توپ از سمت چپ رد بشه و به پارو نخورده باشه => گیم اور
        elif ball.xcor() < -350:
            ball.goto(1000, 1000)
            show_game_over("GAME OVER\nPlayer B Wins!")
            game_over = True

except turtle.Terminator:
    # وقتی کاربر پنجره رو می‌بنده این خطا می‌گیرید؛ اینجا بی‌خطر مدیریتش می‌کنیم
    pass