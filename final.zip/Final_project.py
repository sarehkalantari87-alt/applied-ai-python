import sqlite3
import tkinter as tk
from tkinter import messagebox
b=sqlite3.connect("book.db")
c=b.cursor()
c.execute("CREATE TABLE IF NOT EXISTS book(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,sall INTEGER"
          ",nevisande TEXT,isbn TEXT)")
b.commit()

def search_book():
    listbox.delete(0,tk.END)
    name=entry_name.get()
    c.execute("SELECT * FROM book WHERE name  LIKE ?",("%"+name+"%",))
    for ro in c.fetchall():
        listbox.insert(tk.END,ro)
        b.commit()

def add_book():
        name=entry_name.get()
        sall=entry_sall.get()
        nevisande=entry_nevisande.get()
        isbn=entry_isbn.get()
        if name and sall:
            c.execute("INSERT INTO book(name,sall,nevisande,isbn) VALUES(?,?,?,?)",(name,sall,nevisande,isbn)) 
        else:
            messagebox.showwarning("خطا,اشتباه است")
            b.commit()
            show_book()

def show_book():
    listbox.delete(0,tk.END)
    c.execute("SELECT * FROM book")
    for row in c.fetchall():
        listbox.insert(tk.END,row)

def delet_book():
    selected=listbox.curselection()
    try:
        book=listbox.get(selected)
        c.execute("DELETE * FROM book WHERE id=1",(book[0]))
        b.commit()
        show_book()
    except:
        messagebox.showwarning("خطا,اشتباه است")
        

a=tk.Tk()
a.title("مدریت کتابخانه")
tk.Label(a,text="عنوان").grid(row=0,column=0)
tk.Label(a,text="سال انتشار").grid(row=1,column=0)
tk.Label(a,text="نویسنده").grid(row=0,column=2)
tk.Label(a,text="ISBN").grid(row=1,column=2)

entry_name=tk.Entry(a)
entry_name.grid(row=0,column=1)
entry_sall=tk.Entry(a)
entry_sall.grid(row=1,column=1)
entry_nevisande=tk.Entry(a)
entry_nevisande.grid(row=0,column=3)
entry_isbn=tk.Entry(a)
entry_isbn.grid(row=1,column=3)

tk.Button(a,text="  مشاهده کتاب  ",command=show_book).grid(row=2,column=0)
tk.Button(a,text="   جستجو کتاب   ",command=search_book).grid(row=3,column=0)
tk.Button(a,text="اضافه کردن کتاب",command=add_book).grid(row=4,column=0)
tk.Button(a,text="    حذف کتاب    ",command=delet_book).grid(row=5,column=0)
tk.Button(a,text="        بستن      ",command=a.destroy).grid(row=6,column=0)
listbox=tk.Listbox(width=60)
listbox.grid(row=2,column=1,rowspan=9,columnspan=6,padx=10,pady=10)
a.mainloop()
